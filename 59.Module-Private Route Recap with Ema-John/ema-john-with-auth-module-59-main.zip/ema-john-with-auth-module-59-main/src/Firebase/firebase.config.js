const firebaseConfig = {
    apiKey: "AIzaSyA9QKxeRCIkJqCXnJMwzetm5Ou9NJupWv8",
    authDomain: "ema-john-simple.firebaseapp.com",
    databaseURL: "https://ema-john-simple.firebaseio.com",
    projectId: "ema-john-simple",
    storageBucket: "ema-john-simple.appspot.com",
    messagingSenderId: "753249389312",
    appId: "1:753249389312:web:2539987630fc0a25b201e5"
};

export default firebaseConfig;