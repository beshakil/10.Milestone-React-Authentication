import React from 'react';
import img from '../../images/giphy.gif';

const PlaceOrder = () => {
    return (
        <div>
            <img src={img} alt="" />
        </div>
    );
};

export default PlaceOrder;