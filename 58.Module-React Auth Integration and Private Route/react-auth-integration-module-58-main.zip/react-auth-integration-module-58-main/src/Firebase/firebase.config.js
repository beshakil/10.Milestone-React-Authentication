const firebaseConfig = {
    apiKey: "AIzaSyCNQiJEW74jG7azcr6VLzegTZQbww32LU8",
    authDomain: "simple-firebase-authenti-345f1.firebaseapp.com",
    projectId: "simple-firebase-authenti-345f1",
    storageBucket: "simple-firebase-authenti-345f1.appspot.com",
    messagingSenderId: "282652820885",
    appId: "1:282652820885:web:186d47c412bafbda71629c"
};

export default firebaseConfig;