import React from 'react';

const Shipping = () => {
    return (
        <div>
            <h2>This is Shipping</h2>
        </div>
    );
};

export default Shipping;