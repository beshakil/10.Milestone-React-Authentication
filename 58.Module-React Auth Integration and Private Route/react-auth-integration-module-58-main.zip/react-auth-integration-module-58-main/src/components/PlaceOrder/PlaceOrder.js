import React from 'react';

const PlaceOrder = () => {
    return (
        <div>
            <h2>This is Place Order</h2>
            <h4>Place your order and give us payment</h4>
        </div>
    );
};

export default PlaceOrder;