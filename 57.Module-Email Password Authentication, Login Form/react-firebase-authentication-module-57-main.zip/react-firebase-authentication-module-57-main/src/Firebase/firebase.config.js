const firebaseConfig = {
    apiKey: "AIzaSyAs9GWPmCof5AvSxq8OU6PzSfW0_hRPpho",
    authDomain: "react-firebase-authentic-9cbc5.firebaseapp.com",
    projectId: "react-firebase-authentic-9cbc5",
    storageBucket: "react-firebase-authentic-9cbc5.appspot.com",
    messagingSenderId: "981958236624",
    appId: "1:981958236624:web:9fb0b6fa0652bbda1141d5"
};

export default firebaseConfig;